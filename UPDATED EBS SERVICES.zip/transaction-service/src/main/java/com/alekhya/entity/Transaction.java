package com.alekhya.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Entity
@Data
@Table(name = "transaction") // Define the table name if it's different from the class name
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sno;

    @Temporal(TemporalType.TIMESTAMP)
    private Date date;

    private String description;

    private String drOrCr;

    private double transactionAmount;

    private String accountNumber;

}

