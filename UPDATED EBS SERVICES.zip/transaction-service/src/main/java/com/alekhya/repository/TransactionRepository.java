package com.alekhya.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alekhya.entity.Transaction;

import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByAccountNumber(String accountNumber);
}
    