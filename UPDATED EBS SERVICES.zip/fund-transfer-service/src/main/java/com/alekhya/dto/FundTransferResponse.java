package com.alekhya.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FundTransferResponse {
    private int statusCode;
    private String message;
    private Object data; // You can include additional data if needed
}
