package com.alekhya.controller;

//import com.alekhya.dto.FundTransferRequest;
//import com.alekhya.service.FundTransferService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class FundTransferController {
//
//    private final FundTransferService fundTransferService;
//
//    @Autowired
//    public FundTransferController(FundTransferService fundTransferService) {
//        this.fundTransferService = fundTransferService;
//    }
//
//    @PostMapping("/fund-transfer")
//    public boolean transferFunds(@RequestBody FundTransferRequest request) {
//        return fundTransferService.transferFunds(request);
//    }
//}

//FundTransferController.java


import com.alekhya.dto.FundTransferRequest;
import com.alekhya.service.FundTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FundTransferController {

 private final FundTransferService fundTransferService;

 @Autowired
 public FundTransferController(FundTransferService fundTransferService) {
     this.fundTransferService = fundTransferService;
 }

 @PostMapping("/transfer-funds")
 public String transferFunds(@RequestBody FundTransferRequest request) {
     return fundTransferService.transferFunds(request);
 }
}
