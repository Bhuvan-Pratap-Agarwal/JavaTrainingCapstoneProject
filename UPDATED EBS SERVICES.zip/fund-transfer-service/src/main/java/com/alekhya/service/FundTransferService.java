package com.alekhya.service;
import com.alekhya.dto.FundTransferRequest;

public interface FundTransferService {
 String transferFunds(FundTransferRequest request);
}
