package com.alekhya.service;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.alekhya.dto.FundTransferRequest;
//import com.alekhya.entity.Account;
//import com.alekhya.repository.AccountRepository;
//
//@Service
//public class FundTransferServiceImpl implements FundTransferService {
//
//    private final AccountRepository accountRepository;
//
//    @Autowired
//    public FundTransferServiceImpl(AccountRepository accountRepository) {
//        this.accountRepository = accountRepository;
//    }
//
//    @Override
//    public boolean transferFunds(FundTransferRequest request) {
//        Account sourceAccount = accountRepository.findByAccountNumber(request.getSourceAccountNumber());
//        Account destinationAccount = accountRepository.findByAccountNumber(request.getDestinationAccountNumber());
//
//        if (sourceAccount == null || destinationAccount == null) {
//            return false; // Accounts not found
//        }
//
//        // Check if source account has sufficient balance
//        if (sourceAccount.getAvailableBalance().compareTo(request.getAmount()) < 0) {
//            return false; // Insufficient balance
//        }
//
//        // Update account balances
//        sourceAccount.setAvailableBalance(sourceAccount.getAvailableBalance().subtract(request.getAmount()));
//        destinationAccount.setAvailableBalance(destinationAccount.getAvailableBalance().add(request.getAmount()));
//
//        accountRepository.save(sourceAccount);
//        accountRepository.save(destinationAccount);
//
//        return true; // Transfer successful
//    }
//}


//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.alekhya.dto.FundTransferRequest;
//import com.alekhya.entity.Account;
//import com.alekhya.repository.AccountRepository;
//import com.alekhya.response.FundTransferResponse;
//
//@Service
//public class FundTransferServiceImpl implements FundTransferService {
//
//    @Autowired
//    private AccountRepository accountRepository;
//
//    @Override
//    public FundTransferResponse transferFunds(FundTransferRequest request) {
//        // Check if source account exists and has sufficient balance
//        Account sourceAccount = accountRepository.findByAccountNumber(request.getSourceAccountNumber());
//        if (sourceAccount == null || sourceAccount.getAvailableBalance() < request.getAmount()) {
//            return new FundTransferResponse("Error: Insufficient balance or invalid source account.");
//        }
//
//        // Check if destination account exists
//        Account destinationAccount = accountRepository.findByAccountNumber(request.getDestinationAccountNumber());
//        if (destinationAccount == null) {
//            return new FundTransferResponse("Error: Destination account not found.");
//        }
//
//        // Perform fund transfer
//        sourceAccount.setAvailableBalance(sourceAccount.getAvailableBalance() - request.getAmount());
//        destinationAccount.setAvailableBalance(destinationAccount.getAvailableBalance() + request.getAmount());
//        accountRepository.save(sourceAccount);
//        accountRepository.save(destinationAccount);
//
//        return new FundTransferResponse("Success: Amount transferred successfully.");
//    }
//    
//}

//FundTransferServiceImpl.java


import com.alekhya.dto.FundTransferRequest;
import com.alekhya.entity.Account;
import com.alekhya.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FundTransferServiceImpl implements FundTransferService {

 private final AccountRepository accountRepository;

 @Autowired
 public FundTransferServiceImpl(AccountRepository accountRepository) {
     this.accountRepository = accountRepository;
 }

 @Override
 @Transactional
 public String transferFunds(FundTransferRequest request) {
     Account sourceAccount = accountRepository.findByAccountNumber(request.getSourceAccountNumber());
     Account destinationAccount = accountRepository.findByAccountNumber(request.getDestinationAccountNumber());

     if (sourceAccount == null || destinationAccount == null) {
         return "Invalid account number(s)";
     }

     // Check if source account has sufficient balance
     if (sourceAccount.getAvailableBalance().compareTo(request.getAmount()) < 0) {
         return "Insufficient balance";
     }

     // Perform the fund transfer
     sourceAccount.setAvailableBalance(sourceAccount.getAvailableBalance().subtract(request.getAmount()));
     destinationAccount.setAvailableBalance(destinationAccount.getAvailableBalance().add(request.getAmount()));

     // Update the accounts in the database
     accountRepository.save(sourceAccount);
     accountRepository.save(destinationAccount);

     return "Amount transferred successfully";
 }
}




