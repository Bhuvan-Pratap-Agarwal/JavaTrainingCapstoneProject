package com.alekhya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountSummaryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
