package com.alekhya.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.alekhya.entity.Account;
import com.alekhya.service.AccountSummaryService;

import java.util.List;

@RestController
@RequestMapping("/api/accounts") // Base URL mapping for all endpoints in this controller
public class AccountSummaryController {

    private final AccountSummaryService accountSummaryService;

    @Autowired
    public AccountSummaryController(AccountSummaryService accountSummaryService) {
        this.accountSummaryService = accountSummaryService;
    }

    @GetMapping("/summary/{customerId}")
    public ResponseEntity<?> getAccountSummary(@PathVariable Long customerId) {
        List<Account> accountSummary = accountSummaryService.getAccountSummary(customerId);
        if (accountSummary.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No accounts found for customerId: " + customerId);
        }
        return ResponseEntity.ok(accountSummary);
    }

//    @PostMapping("/add")
//    public ResponseEntity<String> addAccount(@RequestBody Account account) {
//        try {
//            accountSummaryService.addAccount(account);
//            return ResponseEntity.status(HttpStatus.CREATED).body("Account added successfully");
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding account: " + e.getMessage());
//        }
//    }

    // Other controller methods for additional functionality (e.g., update, delete)

}
