package com.alekhya.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alekhya.entity.Account;
import com.alekhya.repository.AccountRepository;

@Service
public class AccountSummaryService {
    private final AccountRepository accountRepository;

    @Autowired
    public AccountSummaryService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

//    public void addAccount(Account account) {
//        // Assuming AccountRepository extends JpaRepository<Account, Long> and provides save() method
//        accountRepository.save(account);
//    }

    public List<Account> getAccountSummary(Long customerId) {
        return accountRepository.findByCustomerId(customerId);
    }
}
 
